Kevin LIESKE
Nicolas REYMOND FORKANI

Pour créer l'exécutable, il faut utiliser la commande make dans le répertoire du projet.

Cette commande va permettre la création des différents exécutables pour chaque version.

Les exécutables sont:
huff_v0 pour la version 1
huff_v1 pour la version 2
huff_v2 pour la version 3
huff_v3 pour la version 4
huff_v4 pour la version 5

L'exécutable de génération de fichiers est test.
Pour utiliser l'exécutable de génération de fichiers, il faut utiliser la commande:
./test (-p <chemin de destination des fichiers>) <nombre de fichier a creer 1-999> (<taille des fichier 0-INT_MAX>) (<nombre de caractere a utiliser 0-255 (ascii = 10 + 32 a 128)>)